/* mine-it — landing page */
(function () {
  'use strict';
  const TOK = 52000;
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, text, style) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; if (style) n.setAttribute('style', style); return n; };
  const fmt = (n) => n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 1 : 2) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'K' : String(Math.round(n));
  const ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 2 ? 'now' : s < 60 ? s + 's ago' : Math.floor(s / 60) + 'm ago'; };

  // ---- buyback feed ----
  let feed = [[2.41, 5], [0.88, 2], [1.73, 4]].map((p, i) => ({ sol: p[0].toFixed(2), tokens: p[1] * TOK, t: Date.now() - (i + 1) * 9000, fresh: false }));
  function renderFeed() {
    const box = $('#feed'); box.textContent = '';
    feed.forEach((f) => {
      const row = el('div', 'feed-row' + (f.fresh ? ' feed-item' : ''));
      const l = el('span', 'l');
      l.append(el('span', null, f.sol + ' SOL', 'color:#F0A04B'), ' bought back → ', el('span', null, fmt(f.tokens) + ' $PICK', 'color:#6FE3C8'), ' buried');
      row.append(l, el('span', 'muted', ago(f.t), 'flex:none'));
      box.appendChild(row);
      f.fresh = false;
    });
  }

  // ---- cave ----
  const cave = window.MineIt.startCave($('#cave'), {
    TOK, buried: 18420000, mined: 6150000,
    onBuyback(crystals) {
      feed = [{ sol: (0.35 + Math.random() * 2.9).toFixed(2), tokens: crystals * TOK, t: Date.now(), fresh: true }].concat(feed).slice(0, 3);
      renderFeed();
    }
  });
  function tick() { $('#buried').textContent = fmt(cave.stats.buried); $('#mined').textContent = fmt(cave.stats.mined); renderFeed(); }
  renderFeed(); tick(); setInterval(tick, 1000);

  // ---- loop strip ----
  const stations = Array.from(document.querySelectorAll('#stations .station'));
  window.MineIt.startTrack($('#track'), (seg) => stations.forEach((s, i) => s.classList.toggle('on', i === seg)));

  // ---- ledger (sample data) ----
  const rows = [
    ['$PICK', 'Pickaxe Pete', 18.4e6, 2.1e6, 1284, 412, '#F0A04B'],
    ['$MOLE', 'Mole Patrol', 31.2e6, 4.6e6, 3902, 920, '#C79A6E'],
    ['$BAT', 'Cave Bat', 12.9e6, 1.4e6, 1066, 301, '#A8977F'],
    ['$GRIT', 'True Grit', 9.7e6, 0.88e6, 644, 187, '#6FE3C8'],
    ['$LAMP', 'Headlamp', 4.1e6, 0.32e6, 211, 58, '#FFE3A0']
  ];
  const max = Math.max.apply(null, rows.map((r) => r[2]));
  const ledger = $('#ledger');
  rows.forEach((r) => {
    const a = el('a', 'row ledger-grid'); a.href = '/mine';
    const coin = el('span', null, null, 'display:flex;align-items:center;gap:12px;min-width:0');
    coin.append(el('span', 'display', r[0].charAt(1), 'width:32px;height:32px;flex:none;background:' + r[6] + ';display:grid;place-items:center;font-size:15px;font-weight:700;color:#120C09'));
    const names = el('span', null, null, 'display:flex;flex-direction:column;min-width:0');
    names.append(el('span', 'display', r[0], 'font-size:19px;font-weight:600'), el('span', 'muted', r[1], 'font-size:12px'));
    coin.append(names);
    const vein = el('span', null, null, 'display:flex;align-items:center;gap:12px');
    const bar = el('span', 'bar'); bar.setAttribute('aria-hidden', 'true');
    const on = Math.max(1, Math.round((r[2] / max) * 24));
    for (let k = 0; k < 24; k++) bar.appendChild(el('span', null, null, 'background:' + (k < on ? (k % 5 === 2 ? '#BFFCEB' : '#5ED9BE') : '#241A14')));
    vein.append(bar, el('span', 'mono num', fmt(r[2]), 'font-size:13px;color:#6FE3C8'));
    a.append(coin, vein, el('span', 'r', fmt(r[3])), el('span', 'r', r[4].toLocaleString('en-US')), el('span', 'r', r[5] + ' SOL', 'color:#F0A04B'), el('span', 'r enter', 'enter →', 'font-size:13px;color:#A8977F;transition:color .15s'));
    ledger.appendChild(a);
  });
})();
