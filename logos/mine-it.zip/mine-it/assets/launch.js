/* mine-it — launch page (front-end demo; no transaction is sent yet) */
(function () {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const mouth = window.MineIt.startMouth($('#mouth'));
  const f = { name: $('#name'), ticker: $('#ticker'), desc: $('#desc'), buy: $('#buy'), img: $('#img') };
  let imgUrl = null, phase = 'form';

  function update() {
    const name = f.name.value.trim();
    const ticker = f.ticker.value;
    const buy = parseFloat(f.buy.value);
    const ready = !!(name && ticker);
    document.querySelectorAll('.t-out').forEach((n) => { n.textContent = '$' + (ticker || 'TICKER'); });
    $('#pv-name').textContent = name || 'Coin name';
    $('#pv-desc').textContent = f.desc.value.trim() || 'Your description shows here.';
    $('#pv-initial').textContent = (ticker || name || '?').charAt(0).toUpperCase();
    $('#pv-buy').textContent = buy > 0 ? buy + ' SOL' : '—';
    $('#pv-miners').textContent = phase === 'live' && buy > 0 ? '1' : '0';
    const go = $('#go');
    go.disabled = !ready || phase === 'opening';
    go.textContent = phase === 'opening' ? 'Opening the mine…' : 'Launch ' + (ticker ? '$' + ticker : 'coin');
    $('#hint').textContent = ready ? 'Ready when you are.' : 'Add a name and a ticker to launch.';
  }

  f.ticker.addEventListener('input', () => {
    const v = f.ticker.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    if (v !== f.ticker.value) f.ticker.value = v;
    update();
  });
  [f.name, f.desc, f.buy].forEach((i) => i.addEventListener('input', update));
  f.img.addEventListener('change', () => {
    const file = f.img.files && f.img.files[0]; if (!file) return;
    if (imgUrl) URL.revokeObjectURL(imgUrl);
    imgUrl = URL.createObjectURL(file);
    const img = $('#pv-img'); img.src = imgUrl; img.hidden = false; $('#pv-initial').hidden = true;
    $('#img-label').textContent = 'Change image';
  });

  $('#form').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!f.name.value.trim() || !f.ticker.value || phase !== 'form') return;
    phase = 'opening'; update();
    setTimeout(() => { phase = 'live'; $('#form').hidden = true; $('#done').hidden = false; mouth.open(); update(); }, 1100);
  });

  $('#again').addEventListener('click', () => {
    phase = 'form';
    $('#form').reset();
    if (imgUrl) { URL.revokeObjectURL(imgUrl); imgUrl = null; }
    $('#pv-img').hidden = true; $('#pv-initial').hidden = false; $('#img-label').textContent = 'Upload image';
    $('#done').hidden = true; $('#form').hidden = false; mouth.close(); update(); f.name.focus();
  });

  update();
})();
