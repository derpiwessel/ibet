/* mine-it — pixel cave engines (canvas 2D, no libraries) */
(function () {
'use strict';
function startCave(cv, opts) {
    opts = opts || {};
    const self = { TOK: opts.TOK || 52000, state: { buried: opts.buried || 0, mined: opts.mined || 0 }, onBuyback: opts.onBuyback || function () {} };
    const W = 320, H = 150;
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const img = ctx.createImageData(W, H), buf = img.data;
    let seed = 20261015;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    const hash = (x, y) => { const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453; return s - Math.floor(s); };
    const noise = (f, amp, off) => { const n = Math.ceil(W / f) + 2, p = []; for (let i = 0; i < n; i++) p.push(rnd()); return (x) => { const t = x / f, i = Math.floor(t), u = t - i, s = u * u * (3 - 2 * u); return (p[i] * (1 - s) + p[i + 1] * s) * amp + off; }; };
    const tA = noise(46, 16, 16), tB = noise(9, 5, 0), bA = noise(54, 14, H - 46), bB = noise(12, 4, 0);
    const top = new Int16Array(W), bot = new Int16Array(W);
    const sx = Math.round(W * 0.6);
    for (let x = 0; x < W; x++) {
      top[x] = Math.round(tA(x) + tB(x));
      bot[x] = Math.round(bA(x) + bB(x));
      const d = Math.abs(x - sx);
      if (d <= 3) top[x] = -1; else if (d <= 8) top[x] = Math.round(top[x] * (d - 3) / 5);
    }
    // materials: 0 air,1 rock,2 crevice,3 ore,4 ore hi,6 wood,7 sky
    const mat = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (y <= top[x] || y >= bot[x]) {
        const h = hash(x, y);
        mat[i] = (h < 0.1 || ((y + Math.round(tB(x))) % 11 === 0 && h < 0.55)) ? 2 : 1;
      } else mat[i] = 0;
      if (Math.abs(x - sx) <= 3 && y < 4) mat[i] = 7;
    }
    const setM = (x, y, m) => { if (x >= 0 && x < W && y >= 0 && y < H) mat[y * W + x] = m; };
    const getM = (x, y) => (x >= 0 && x < W && y >= 0 && y < H) ? mat[y * W + x] : 1;
    // stalactites + stalagmites
    for (let k = 0; k < 14; k++) {
      const x = Math.floor(rnd() * W); if (Math.abs(x - sx) < 12) continue;
      const len = 3 + Math.floor(rnd() * 9);
      for (let j = 0; j < len; j++) { const w = j < len * 0.45 ? 1 : 0; for (let dx = -w; dx <= w; dx++) if (getM(x + dx, top[x] + 1 + j) === 0) setM(x + dx, top[x] + 1 + j, hash(x, j) < 0.2 ? 2 : 1); }
    }
    // timber props + torches
    const props = [Math.round(W * 0.2), Math.round(W * 0.86)];
    const torches = [];
    props.forEach((px) => {
      const l = px - 7, r = px + 7;
      const beamY = Math.max(top[l], top[r], top[px]) + 3;
      for (let y = beamY; y < bot[l]; y++) setM(l, y, 6);
      for (let y = beamY; y < bot[r]; y++) setM(r, y, 6);
      for (let x = l; x <= r; x++) { setM(x, beamY, 6); setM(x, beamY + 1, 6); }
      torches.push({ x: l + 2, y: beamY + 9, ph: rnd() * 6 });
    });
    // veins
    const veinXs = [0.08, 0.33, 0.47, 0.73, 0.95].map((f) => Math.round(W * f));
    const veins = veinXs.map((vx) => {
      const fy = bot[vx], cells = [];
      for (let dy = 0; dy <= 6; dy++) for (let dx = -8; dx <= 8; dx++) {
        const x = vx + dx, y = fy + dy;
        if ((dx / 8.5) ** 2 + (dy / 6) ** 2 > 1) continue;
        const m = getM(x, y); if (m !== 1 && m !== 2) continue;
        if (hash(x * 3, y * 7) < 0.3) continue;
        cells.push({ i: y * W + x, x, y, base: m, hi: hash(x, y * 3) > 0.78 });
      }
      cells.sort((a, b) => (a.y - b.y) || (Math.abs(a.x - vx) - Math.abs(b.x - vx)));
      return { x: vx, y: fy, cells, amount: Math.floor(cells.length * (0.35 + rnd() * 0.4)), claim: 0 };
    });
    const applyVein = (v) => { v.cells.forEach((c, k) => { mat[c.i] = k < v.amount ? (c.hi ? 4 : 3) : c.base; }); };
    veins.forEach(applyVein);

    const PAL = {
      0: ['#060404', '#0D0907', '#18100B', '#261A11'],
      1: ['#120C09', '#24180F', '#3B2919', '#5C4027'],
      2: ['#0B0705', '#160E09', '#26190F', '#3D2A19'],
      3: ['#1A4F46', '#2A8576', '#5ED9BE', '#BFFCEB'],
      4: ['#2A8576', '#5ED9BE', '#BFFCEB', '#FFFFFF'],
      6: ['#1C1109', '#3A230F', '#5E3A18', '#8A5626'],
      7: ['#1E2A33', '#1E2A33', '#2A3A45', '#2A3A45']
    };
    const RGB = {};
    Object.keys(PAL).forEach((k) => { RGB[k] = PAL[k].map((h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]); });
    const bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

    const stats = { buried: self.state.buried, mined: self.state.mined };
    const parts = [];
    const chunks = [];
    const miners = [0.15, 0.55, 0.8].map((f, k) => ({ x: W * f, dir: 1, vein: null, t: k * 5, walk: 0 }));
    const cursor = { x: -99, y: -99, i: 0, on: false };
    let frame = 0, nextBuy = 40, raf = 0, last = 0, acc = 0, running = true, visible = true;

    const chips = (x, y, n) => { for (let k = 0; k < n; k++) parts.push({ kind: 'chip', x, y, vx: (rnd() - 0.5) * 2.2, vy: -0.6 - rnd() * 1.6, life: 26 + rnd() * 12, c: rnd() < 0.3 ? '#BFFCEB' : '#5ED9BE' }); };
    const strike = (v) => {
      if (v.amount <= 0) return false;
      v.amount--; applyVein(v);
      const c = v.cells[v.amount]; chips(c.x, c.y - 1, 5);
      stats.mined += self.TOK; stats.buried = Math.max(0, stats.buried - self.TOK);
      return true;
    };
    const spawnBuy = () => { chunks.push({ x: sx + Math.round((rnd() - 0.5) * 3), y: -3, vy: 0 }); };
    const land = (ch) => {
      const open = veins.filter((v) => v.amount + v.claim < v.cells.length);
      if (!open.length) return;
      const v = open[Math.floor(rnd() * open.length)];
      const add = Math.min(2 + Math.floor(rnd() * 4), v.cells.length - v.amount - v.claim);
      v.claim += add;
      for (let k = 0; k < add; k++) {
        const target = v.cells[Math.min(v.cells.length - 1, v.amount + v.claim - add + k)];
        parts.push({ kind: 'ore', x: ch.x, y: ch.y, p0: [ch.x, ch.y], p2: [target.x, target.y], p1: [(ch.x + target.x) / 2, Math.min(ch.y, target.y) - 18 - rnd() * 18], t: -k * 0.08, sp: 0.022 + rnd() * 0.01, v });
      }
      for (let k = 0; k < 8; k++) parts.push({ kind: 'spark', x: ch.x, y: ch.y - 1, vx: (rnd() - 0.5) * 2, vy: -rnd() * 1.8, life: 14 + rnd() * 8, c: '#FFE3A0' });
      stats.buried += add * self.TOK;
      self.onBuyback(add);
    };

    const step = () => {
      frame++;
      if (--nextBuy <= 0) { spawnBuy(); nextBuy = 80 + Math.floor(rnd() * 50); }
      for (let k = chunks.length - 1; k >= 0; k--) {
        const ch = chunks[k]; ch.vy = Math.min(3, ch.vy + 0.12); ch.y += ch.vy;
        if (ch.y >= bot[Math.round(ch.x)] - 1) { ch.y = bot[Math.round(ch.x)] - 1; land(ch); chunks.splice(k, 1); }
      }
      for (let k = parts.length - 1; k >= 0; k--) {
        const p = parts[k];
        if (p.kind === 'ore') {
          p.t += p.sp; if (p.t < 0) continue;
          const t = Math.min(1, p.t), u = 1 - t;
          p.x = u * u * p.p0[0] + 2 * u * t * p.p1[0] + t * t * p.p2[0];
          p.y = u * u * p.p0[1] + 2 * u * t * p.p1[1] + t * t * p.p2[1];
          if (t >= 1) { p.v.claim--; p.v.amount = Math.min(p.v.cells.length, p.v.amount + 1); applyVein(p.v); chips(p.x, p.y - 1, 2); parts.splice(k, 1); }
        } else {
          p.vy += 0.12; p.x += p.vx; p.y += p.vy; p.life--;
          const gx = Math.round(p.x), gy = Math.round(p.y);
          if (p.life <= 0 || (getM(gx, gy) !== 0 && getM(gx, gy) !== 7 && p.vy > 0)) parts.splice(k, 1);
        }
      }
      miners.forEach((m, mi) => {
        if (!m.vein || m.vein.amount <= 0) {
          let best = null, bd = 1e9;
          veins.forEach((v) => { if (v.amount <= 0) return; const taken = miners.some((o, oi) => oi !== mi && o.vein === v); const d = Math.abs(v.x - m.x) + (taken ? 120 : 0); if (d < bd) { bd = d; best = v; } });
          m.vein = best; m.t = 0;
        }
        if (!m.vein) { m.walk = 0; return; }
        const side = m.x < m.vein.x ? -1 : 1;
        const tx = m.vein.x + side * 9;
        if (Math.abs(tx - m.x) > 0.6) { m.dir = Math.sign(tx - m.x); m.x += m.dir * 0.4; m.walk++; m.t = 0; }
        else { m.dir = -side; m.walk = 0; m.t++; if (m.t % 18 === 9) strike(m.vein); }
      });
      cursor.i += ((cursor.on ? 1 : 0) - cursor.i) * 0.12;
    };

    const draw = () => {
      const lights = [];
      lights.push({ x: sx, y: -8, r: 80, i: 0.95 });
      torches.forEach((t) => lights.push({ x: t.x, y: t.y, r: 66, i: 0.95 + Math.sin(frame * 0.35 + t.ph) * 0.06 + (rnd() - 0.5) * 0.06 }));
      veins.forEach((v) => { if (v.amount > 0) lights.push({ x: v.x, y: v.y + 1, r: Math.min(26, 9 + v.amount * 0.35), i: 0.55 + Math.sin(frame * 0.08 + v.x) * 0.08 }); });
      miners.forEach((m) => lights.push({ x: m.x + m.dir * 2, y: bot[Math.round(m.x)] - 7, r: 24, i: 0.6 }));
      chunks.forEach((c) => lights.push({ x: c.x, y: c.y, r: 18, i: 0.8 }));
      if (cursor.i > 0.02) lights.push({ x: cursor.x, y: cursor.y, r: 44, i: 1.05 * cursor.i });
      lights.forEach((l) => { l.r2 = l.r * l.r; });
      const pulse = Math.sin(frame * 0.12) > 0.4 ? 1 : 0;
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, m = mat[i];
        let L = 0.17;
        for (let k = 0; k < lights.length; k++) { const l = lights[k], dx = x - l.x, dy = (y - l.y) * 1.15, d2 = dx * dx + dy * dy; if (d2 < l.r2) L += (1 - Math.sqrt(d2) / l.r) * l.i; }
        let lv = Math.floor(L * 3.1 + bayer[(x & 3) + ((y & 3) << 2)] / 16 - 0.3);
        if (lv < 0) lv = 0; else if (lv > 3) lv = 3;
        if (m === 3 || m === 4) lv = Math.max(lv, 1 + ((pulse && hash(x, y) > 0.6) ? 1 : 0));
        const c = RGB[m][lv], o = i * 4;
        buf[o] = c[0]; buf[o + 1] = c[1]; buf[o + 2] = c[2]; buf[o + 3] = 255;
      }
      ctx.putImageData(img, 0, 0);
      const px = (x, y, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); };
      // torches
      torches.forEach((t) => {
        const f = (frame + Math.round(t.ph * 3)) % 6 < 3;
        px(t.x, t.y + 1, '#5E3A18'); px(t.x, t.y + 2, '#5E3A18');
        px(t.x, t.y, '#F0A04B'); px(t.x, t.y - 1, f ? '#FFE3A0' : '#F0A04B'); if (f) px(t.x - 1, t.y - 1, '#F0A04B'); else px(t.x + 1, t.y - 2, '#FFE3A0');
      });
      // falling buyback chunks
      chunks.forEach((c) => {
        ctx.fillStyle = 'rgba(240,160,75,0.35)'; ctx.fillRect(Math.round(c.x) - 1, Math.round(c.y) - 6, 3, 5);
        ctx.fillStyle = '#F0A04B'; ctx.fillRect(Math.round(c.x) - 1, Math.round(c.y) - 1, 3, 3);
        px(c.x, c.y, '#FFFFFF');
      });
      // miners
      miners.forEach((m) => {
        const fx = Math.round(m.x), fy = bot[fx];
        const d = m.dir;
        const P = (ox, oy, c) => px(fx + ox * d, fy + oy, c);
        const leg = m.walk ? (Math.floor(m.walk / 6) % 2) : 0;
        P(-1, -1, '#2B2622'); P(1, -1, '#2B2622'); if (leg) { P(-1, -1, '#0C0907'); P(-2, -1, '#2B2622'); }
        P(-1, -2, '#46596A'); P(0, -2, '#46596A'); P(1, -2, '#46596A');
        P(-1, -3, '#5A6E7A'); P(0, -3, '#5A6E7A'); P(1, -3, '#5A6E7A');
        P(0, -4, '#C79A6E'); P(1, -4, '#C79A6E');
        P(-1, -5, '#C9892F'); P(0, -5, '#C9892F'); P(1, -5, '#C9892F'); P(2, -5, '#FFE3A0');
        P(0, -6, '#C9892F');
        const up = m.vein && !m.walk && (m.t % 18) < 9;
        if (m.vein && !m.walk) {
          if (up) { P(2, -4, '#8A5626'); P(2, -5, '#8A5626'); P(2, -6, '#8A5626'); P(1, -7, '#B9C0BE'); P(2, -7, '#B9C0BE'); P(3, -7, '#B9C0BE'); }
          else { P(2, -3, '#8A5626'); P(3, -3, '#8A5626'); P(4, -3, '#8A5626'); P(5, -4, '#B9C0BE'); P(5, -3, '#B9C0BE'); P(5, -2, '#B9C0BE'); }
        } else { P(2, -3, '#8A5626'); P(2, -2, '#8A5626'); P(3, -4, '#B9C0BE'); }
      });
      // particles
      parts.forEach((p) => {
        if (p.kind === 'ore') { if (p.t < 0) return; px(p.x, p.y, '#BFFCEB'); ctx.fillStyle = 'rgba(111,227,200,0.45)'; ctx.fillRect(Math.round(p.x) - 1, Math.round(p.y), 1, 1); }
        else px(p.x, p.y, p.c);
      });
      // cursor torch
      if (cursor.i > 0.05) { const f = frame % 6 < 3; px(cursor.x, cursor.y, '#F0A04B'); px(cursor.x, cursor.y - 1, f ? '#FFE3A0' : '#F0A04B'); px(cursor.x, cursor.y + 1, '#5E3A18'); px(cursor.x, cursor.y + 2, '#5E3A18'); }
    };

    const toLocal = (e) => { const r = cv.getBoundingClientRect(); return [((e.clientX - r.left) / r.width) * W, ((e.clientY - r.top) / r.height) * H]; };
    const onMove = (e) => { const p = toLocal(e); cursor.x = p[0]; cursor.y = p[1]; cursor.on = true; if (reduced) draw(); };
    const onLeave = () => { cursor.on = false; if (reduced) { cursor.i = 0; draw(); } };
    const onDown = (e) => {
      const p = toLocal(e); let best = null, bd = 20;
      veins.forEach((v) => { const d = Math.hypot(v.x - p[0], (v.y + 2 - p[1]) * 1.2); if (d < bd && v.amount > 0) { bd = d; best = v; } });
      if (best) { strike(best); strike(best); stats.mined = stats.mined; }
      if (reduced) draw();
    };
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerleave', onLeave);
    cv.addEventListener('pointerdown', onDown);

    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let io = null;
    if ('IntersectionObserver' in window) { io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; }); io.observe(cv); }
    const loop = (ts) => {
      if (!running) return;
      raf = requestAnimationFrame(loop);
      if (!visible) { last = ts; return; }
      acc += Math.min(100, ts - (last || ts)); last = ts;
      let stepped = false;
      while (acc >= 33) { step(); acc -= 33; stepped = true; }
      if (stepped) draw();
    };
    if (reduced) { for (let k = 0; k < 120; k++) step(); draw(); }
    else raf = requestAnimationFrame(loop);
    return {
      stats,
      stop: () => { running = false; cancelAnimationFrame(raf); if (io) io.disconnect(); cv.removeEventListener('pointermove', onMove); cv.removeEventListener('pointerleave', onLeave); cv.removeEventListener('pointerdown', onDown); }
    };
  }

function startTrack(cv, onStation) {
    const self = { setState: (o) => { if (onStation) onStation(o.station); } };
    const W = 320, H = 44;
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const hash = (x, y) => { const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453; return s - Math.floor(s); };
    const R = 31;
    const stationX = [40, 120, 200, 280];
    const veinCells = [];
    for (let dy = 0; dy < 6; dy++) for (let dx = -12; dx <= 12; dx++) { if ((dx / 12.5) ** 2 + (dy / 6) ** 2 > 1 || hash(dx, dy) < 0.35) continue; veinCells.push({ x: 236 + dx, y: R + 4 + dy, hi: hash(dx * 2, dy) > 0.75 }); }
    veinCells.sort((a, b) => a.y - b.y);
    let raf = 0, running = true, last = 0, t = 0, active = -1, frame = 0, fill = 8;
    const chipsArr = [];
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const px = (x, y, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); };
    const draw = () => {
      ctx.fillStyle = '#0B0806'; ctx.fillRect(0, 0, W, H);
      // rock below rails
      for (let y = R + 3; y < H; y++) for (let x = 0; x < W; x++) { const h = hash(x, y); px(x, y, h < 0.12 ? '#160E09' : (h < 0.5 ? '#24180F' : '#2C1E13')); }
      // station posts + lamps
      stationX.forEach((sxp, k) => {
        const on = k === active;
        for (let y = 10; y < R; y++) px(sxp, y, '#3A230F');
        px(sxp - 1, 10, '#3A230F'); px(sxp + 1, 10, '#3A230F');
        px(sxp, 9, on ? '#6FE3C8' : '#5C4027'); px(sxp - 1, 9, on ? '#2A8576' : '#3B2919'); px(sxp + 1, 9, on ? '#2A8576' : '#3B2919');
        if (on) { ctx.fillStyle = 'rgba(111,227,200,0.12)'; ctx.fillRect(sxp - 10, 4, 21, R - 4); }
      });
      // vein under station 3-4
      const shown = Math.round(veinCells.length * Math.min(1, fill / 24));
      veinCells.forEach((c, k) => { if (k < shown) px(c.x, c.y, c.hi ? '#BFFCEB' : (frame % 20 < 10 || !c.hi ? '#5ED9BE' : '#2A8576')); });
      // rails + ties
      for (let x = 0; x < W; x++) { px(x, R + 1, '#7E705E'); if (x % 4 === 0) { px(x, R + 2, '#5E3A18'); px(x + 1, R + 2, '#5E3A18'); } }
      // cart
      const cx = -20 + (t % 1) * 360;
      const seg = cx < 80 ? 0 : cx < 160 ? 1 : cx < 230 ? 2 : 3;
      const cargo = cx < 120 ? 'fee' : cx < 214 ? 'tok' : 'none';
      const x0 = Math.round(cx - 6);
      for (let y = R - 6; y <= R - 1; y++) for (let x = x0; x < x0 + 13; x++) { const edge = x === x0 || x === x0 + 12 || y === R - 1; px(x, y, edge ? '#5A6E7A' : '#46596A'); }
      px(x0 + 2, R, '#2B2622'); px(x0 + 3, R, '#2B2622'); px(x0 + 9, R, '#2B2622'); px(x0 + 10, R, '#2B2622');
      if (cargo !== 'none') for (let x = x0 + 1; x < x0 + 12; x++) for (let y = R - 9; y < R - 6; y++) { if ((y === R - 9 && (x < x0 + 3 || x > x0 + 9))) continue; const h = hash(x - x0, y); px(x, y, cargo === 'fee' ? (h < 0.4 ? '#FFE3A0' : '#F0A04B') : (h < 0.4 ? '#FFFFFF' : '#EFE6D8')); }
      if (cx > 214 && cx < 232) { for (let k = 0; k < 3; k++) px(x0 + 6 + k, R - 6 + ((frame + k * 2) % 6), '#EFE6D8'); }
      // miner at station 4
      const mx = 262, my = R;
      const up = frame % 16 < 8;
      [[-1, -1, '#2B2622'], [1, -1, '#2B2622'], [-1, -2, '#46596A'], [0, -2, '#46596A'], [1, -2, '#46596A'], [-1, -3, '#5A6E7A'], [0, -3, '#5A6E7A'], [1, -3, '#5A6E7A'], [0, -4, '#C79A6E'], [-1, -4, '#C79A6E'], [-2, -5, '#FFE3A0'], [-1, -5, '#C9892F'], [0, -5, '#C9892F'], [1, -5, '#C9892F'], [0, -6, '#C9892F']].forEach((p) => px(mx + p[0], my + p[1], p[2]));
      if (up) { [[-2, -4], [-2, -5], [-2, -6]].forEach((p) => px(mx + p[0], my + p[1], '#8A5626')); [[-1, -7], [-2, -7], [-3, -7]].forEach((p) => px(mx + p[0], my + p[1], '#B9C0BE')); }
      else { [[-2, -3], [-3, -2], [-4, -1]].forEach((p) => px(mx + p[0], my + p[1], '#8A5626')); [[-5, -2], [-5, -1], [-5, 0]].forEach((p) => px(mx + p[0], my + p[1], '#B9C0BE')); }
      chipsArr.forEach((c) => px(c.x, c.y, c.c));
      return seg;
    };
    const step = () => {
      frame++;
      t += 1 / (30 * 9);
      const cx = -20 + (t % 1) * 360;
      if (cx > 214 && cx < 232 && frame % 2 === 0) fill = Math.min(24, fill + 0.6);
      if (frame % 16 === 8 && fill > 2) { fill -= 0.35; for (let k = 0; k < 3; k++) chipsArr.push({ x: 256, y: R - 1, vx: -0.4 - Math.random() * 1.2, vy: -1 - Math.random() * 1.2, life: 22, c: Math.random() < 0.4 ? '#BFFCEB' : '#5ED9BE' }); }
      for (let k = chipsArr.length - 1; k >= 0; k--) { const c = chipsArr[k]; c.vy += 0.1; c.x += c.vx; c.y += c.vy; if (--c.life <= 0 || c.y > R) chipsArr.splice(k, 1); }
    };
    const loop = (ts) => {
      if (!running) return;
      raf = requestAnimationFrame(loop);
      if (ts - last < 33) return; last = ts;
      step();
      const seg = draw();
      if (seg !== active) { active = seg; self.setState({ station: seg }); }
    };
    if (reduced) { active = 3; draw(); self.setState({ station: -1 }); }
    else raf = requestAnimationFrame(loop);
    return { stop: () => { running = false; cancelAnimationFrame(raf); } };
  }

function startShaft(cv) {

    const W = 240, H = 140;
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const img = ctx.createImageData(W, H), buf = img.data;
    let seed = 4242;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    const hash = (x, y) => { const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453; return s - Math.floor(s); };
    const noise = (n0, f, amp, off) => { const n = Math.ceil(n0 / f) + 2, p = []; for (let i = 0; i < n; i++) p.push(rnd()); return (x) => { const t = x / f, i = Math.floor(t), u = t - i, s = u * u * (3 - 2 * u); return (p[i] * (1 - s) + p[i + 1] * s) * amp + off; }; };
    const SX0 = 18, SX1 = 32;
    const cT = noise(W, 30, 12, 34), cB = noise(W, 34, 8, 112), wR = noise(H, 18, 10, 196);
    const mat = new Uint8Array(W * H);
    const floorY = new Int16Array(W);
    for (let x = 0; x < W; x++) floorY[x] = x <= SX1 + 2 ? 118 : Math.round(cB(x));
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const inShaft = x >= SX0 && x <= SX1 && y < 118;
      const inCave = x > SX0 && y > cT(x) && y < floorY[x] && x < wR(y);
      if (inShaft || inCave) mat[i] = (y < 3 && inShaft) ? 7 : 0;
      else { const h = hash(x, y); mat[i] = (h < 0.1 || (y % 9 === 0 && h < 0.5)) ? 2 : 1; }
    }
    // shaft guide rails (wood)
    for (let y = 0; y < 118; y++) { mat[y * W + SX0] = 6; mat[y * W + SX1] = 6; }
    // vein in the right wall
    const cells = [];
    for (let y = 50; y < 112; y++) for (let x = 170; x < W; x++) {
      const i = y * W + x; if (mat[i] !== 1 && mat[i] !== 2) continue;
      const edge = wR(y); if (x < edge || x > edge + 14) continue;
      if ((x - edge) / 14 + Math.abs(y - 84) / 34 > 1) continue;
      if (hash(x * 3, y * 5) < 0.28) continue;
      cells.push({ i, x, y, base: mat[i], hi: hash(x, y * 2) > 0.78 });
    }
    cells.sort((a, b) => (a.x - b.x));
    let amount = Math.floor(cells.length * 0.7);
    const apply = () => cells.forEach((c, k) => { mat[c.i] = k < amount ? (c.hi ? 4 : 3) : c.base; });
    apply();
    const PAL = {
      0: ['#060404', '#0D0907', '#18100B', '#261A11'], 1: ['#120C09', '#24180F', '#3B2919', '#5C4027'], 2: ['#0B0705', '#160E09', '#26190F', '#3D2A19'],
      3: ['#1A4F46', '#2A8576', '#5ED9BE', '#BFFCEB'], 4: ['#2A8576', '#5ED9BE', '#BFFCEB', '#FFFFFF'], 6: ['#1C1109', '#3A230F', '#5E3A18', '#8A5626'], 7: ['#1E2A33', '#1E2A33', '#2A3A45', '#2A3A45']
    };
    const RGB = {}; Object.keys(PAL).forEach((k) => { RGB[k] = PAL[k].map((h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]); });
    const bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    const vx = Math.round(wR(100)) - 1;
    const miner = { x: vx - 8, t: 0 };
    const torch = { x: 60, y: Math.round(cT(60)) + 10 };
    const cart = { x: 44, fill: 6, y: 0, state: 'park', cb: null };
    const cage = { y: 117 };
    const parts = [];
    let frame = 0, raf = 0, last = 0, running = true, visible = true;
    const px = (x, y, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); };
    const step = () => {
      frame++;
      // miner swings
      miner.t++;
      if (miner.t % 18 === 9 && amount > 4) {
        const c = cells[Math.max(0, amount - 1)];
        amount = Math.max(4, amount - (frame % 3 === 0 ? 1 : 0)); apply();
        for (let k = 0; k < 4; k++) parts.push({ x: c.x - 1, y: c.y, vx: -0.6 - Math.random() * 1.4, vy: -1.2 - Math.random() * 1.2, life: 60, c: Math.random() < 0.3 ? '#BFFCEB' : '#5ED9BE', toCart: k < 2 });
      }
      for (let k = parts.length - 1; k >= 0; k--) {
        const p = parts[k];
        if (p.toCart && cart.state === 'park') { const tx = cart.x + 6, ty = 112; p.vx += (tx - p.x) * 0.004; }
        p.vy += 0.1; p.x += p.vx; p.y += p.vy; p.life--;
        const fy = floorY[Math.max(0, Math.min(W - 1, Math.round(p.x)))];
        if (p.toCart && cart.state === 'park' && Math.abs(p.x - (cart.x + 6)) < 6 && p.y > 108) { cart.fill = Math.min(14, cart.fill + 0.25); parts.splice(k, 1); continue; }
        if (p.life <= 0 || p.y >= fy - 1) parts.splice(k, 1);
      }
      // haul sequence
      if (cart.state === 'toCage') { cart.x -= 0.8; if (cart.x <= SX0 + 1) { cart.x = SX0 + 1; cart.state = 'up'; } }
      else if (cart.state === 'up') { cage.y -= 1.4; if (cage.y <= 10) { cage.y = 10; cart.state = 'top'; cart.wait = 14; for (let k = 0; k < 10; k++) parts.push({ x: SX0 + 7, y: 6, vx: (Math.random() - 0.5) * 2, vy: -1 - Math.random(), life: 22, c: '#FFE3A0' }); } }
      else if (cart.state === 'top') { if (--cart.wait <= 0) { cart.fill = 0; cart.state = 'down'; if (cart.cb) { const cb = cart.cb; cart.cb = null; cb(); } } }
      else if (cart.state === 'down') { cage.y += 1.6; if (cage.y >= 117) { cage.y = 117; cart.state = 'out'; } }
      else if (cart.state === 'out') { cart.x += 0.8; if (cart.x >= 44) { cart.x = 44; cart.state = 'park'; } }
      if (cart.state !== 'park') cart.y = cart.state === 'toCage' || cart.state === 'out' ? 0 : cage.y - 117;
    };
    const draw = () => {
      const lights = [{ x: (SX0 + SX1) / 2, y: -6, r: 46, i: 0.8 }, { x: torch.x, y: torch.y, r: 52, i: 0.95 + Math.sin(frame * 0.35) * 0.06 }, { x: vx + 6, y: 84, r: 30, i: 0.6 }, { x: miner.x + 2, y: 110, r: 24, i: 0.6 }, { x: SX0 + 7, y: cage.y - 8, r: 16, i: 0.5 }];
      lights.forEach((l) => { l.r2 = l.r * l.r; });
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, m = mat[i];
        let L = 0.15;
        for (let k = 0; k < lights.length; k++) { const l = lights[k], dx = x - l.x, dy = (y - l.y) * 1.1, d2 = dx * dx + dy * dy; if (d2 < l.r2) L += (1 - Math.sqrt(d2) / l.r) * l.i; }
        let lv = Math.floor(L * 3.1 + bayer[(x & 3) + ((y & 3) << 2)] / 16 - 0.3); lv = lv < 0 ? 0 : lv > 3 ? 3 : lv;
        if (m === 3 || m === 4) lv = Math.max(lv, 1 + (Math.sin(frame * 0.12 + x) > 0.6 ? 1 : 0));
        const c = RGB[m][lv], o = i * 4; buf[o] = c[0]; buf[o + 1] = c[1]; buf[o + 2] = c[2]; buf[o + 3] = 255;
      }
      ctx.putImageData(img, 0, 0);
      // torch
      const f = frame % 6 < 3; px(torch.x, torch.y + 1, '#5E3A18'); px(torch.x, torch.y + 2, '#5E3A18'); px(torch.x, torch.y, '#F0A04B'); px(torch.x, torch.y - 1, f ? '#FFE3A0' : '#F0A04B');
      // cage
      const cy = Math.round(cage.y);
      ctx.fillStyle = '#5A6E7A'; ctx.fillRect(SX0 + 1, cy - 12, SX1 - SX0 - 1, 1); ctx.fillRect(SX0 + 1, cy, SX1 - SX0 - 1, 1);
      for (let y = cy - 12; y <= cy; y++) { px(SX0 + 1, y, '#46596A'); px(SX1 - 1, y, '#46596A'); }
      ctx.fillStyle = '#7E705E'; ctx.fillRect(SX0 + 7, 0, 1, Math.max(0, cy - 12));
      // cart
      const cx = Math.round(cart.x), cyy = (cart.state === 'up' || cart.state === 'top' || cart.state === 'down') ? cy - 1 : 117;
      for (let y = cyy - 5; y <= cyy; y++) for (let x = cx; x < cx + 12; x++) px(x, y, (x === cx || x === cx + 11 || y === cyy) ? '#5A6E7A' : '#46596A');
      px(cx + 2, cyy + 1, '#2B2622'); px(cx + 9, cyy + 1, '#2B2622');
      const fl = Math.round(cart.fill / 3.5);
      for (let r = 0; r < fl; r++) for (let x = cx + 1; x < cx + 11; x++) if (hash(x - cx, r) > 0.2) px(x, cyy - 5 - r + 1, hash(x, r) > 0.7 ? '#BFFCEB' : '#5ED9BE');
      // miner (faces right)
      const mx = Math.round(miner.x), my = floorY[mx];
      const P = (ox, oy, c) => px(mx + ox, my + oy, c);
      P(-1, -1, '#2B2622'); P(1, -1, '#2B2622'); P(-1, -2, '#46596A'); P(0, -2, '#46596A'); P(1, -2, '#46596A');
      P(-1, -3, '#5A6E7A'); P(0, -3, '#5A6E7A'); P(1, -3, '#5A6E7A'); P(0, -4, '#C79A6E'); P(1, -4, '#C79A6E');
      P(-1, -5, '#C9892F'); P(0, -5, '#C9892F'); P(1, -5, '#C9892F'); P(2, -5, '#FFE3A0'); P(0, -6, '#C9892F');
      if (miner.t % 18 < 9) { P(2, -4, '#8A5626'); P(2, -5, '#8A5626'); P(2, -6, '#8A5626'); P(1, -7, '#B9C0BE'); P(2, -7, '#B9C0BE'); P(3, -7, '#B9C0BE'); }
      else { P(2, -3, '#8A5626'); P(3, -3, '#8A5626'); P(4, -3, '#8A5626'); P(5, -4, '#B9C0BE'); P(5, -3, '#B9C0BE'); P(5, -2, '#B9C0BE'); }
      parts.forEach((p) => px(p.x, p.y, p.c));
    };
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let io = null;
    if ('IntersectionObserver' in window) { io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; }); io.observe(cv); }
    const loop = (ts) => {
      if (!running) return;
      raf = requestAnimationFrame(loop);
      if (!visible || ts - last < 33) return; last = ts;
      step(); draw();
    };
    if (reduced) { for (let k = 0; k < 40; k++) step(); draw(); } else raf = requestAnimationFrame(loop);
    return {
      haul: (cb) => { if (reduced) { cart.fill = 0; draw(); cb(); return; } if (cart.state !== 'park') { cb(); return; } cart.cb = cb; cart.state = 'toCage'; },
      buyback: () => { amount = Math.min(cells.length, amount + 6); apply(); for (let k = 0; k < 8; k++) parts.push({ x: vx + 4, y: 84 + (Math.random() - 0.5) * 30, vx: (Math.random() - 0.5), vy: -Math.random(), life: 16, c: '#FFE3A0' }); if (reduced) draw(); },
      stop: () => { running = false; cancelAnimationFrame(raf); if (io) io.disconnect(); }
    };
  }

function startMouth(cv) {
    const W = 160, H = 90;
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const img = ctx.createImageData(W, H), buf = img.data;
    let seed = 777;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    const hash = (x, y) => { const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453; return s - Math.floor(s); };
    const pts = []; for (let i = 0; i < 8; i++) pts.push(rnd());
    const hill = (x) => { const t = x / 26, i = Math.floor(t), u = t - i, s = u * u * (3 - 2 * u); return 18 + (pts[i] * (1 - s) + pts[i + 1] * s) * 14 + Math.abs(x - 80) * 0.12; };
    const cx = 80, gy = 78;
    const mat = new Uint8Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (y < hill(x)) { mat[i] = 7; continue; }
      if (y >= gy) { mat[i] = hash(x, y) < 0.15 ? 2 : 1; continue; }
      const dx = (x - cx) / 17, dy = (y - (gy - 2)) / 30;
      if (dx * dx + dy * dy < 1 && y > gy - 32) { mat[i] = 0; continue; }
      const h = hash(x, y); mat[i] = (h < 0.1 || (y % 8 === 0 && h < 0.45)) ? 2 : 1;
    }
    // timber frame
    for (let y = gy - 26; y < gy; y++) { mat[y * W + cx - 15] = 6; mat[y * W + cx - 14] = 6; mat[y * W + cx + 14] = 6; mat[y * W + cx + 15] = 6; }
    for (let x = cx - 17; x <= cx + 17; x++) { mat[(gy - 27) * W + x] = 6; mat[(gy - 26) * W + x] = 6; }
    // stars
    const stars = []; for (let k = 0; k < 18; k++) { const x = Math.floor(rnd() * W), y = Math.floor(rnd() * 22); if (mat[y * W + x] === 7) stars.push([x, y]); }
    // floor ore inside the mouth (revealed after launch)
    const cells = [];
    for (let y = gy; y < gy + 4; y++) for (let x = cx - 10; x <= cx + 10; x++) { if (hash(x * 2, y) < 0.35) continue; if (Math.abs(x - cx) / 10 + (y - gy) / 4 > 1) continue; cells.push({ i: y * W + x, base: mat[y * W + x], hi: hash(x, y * 3) > 0.75, k: hash(x * 5, y * 7) }); }
    cells.sort((a, b) => a.k - b.k);
    let shown = 0, target = 0;
    const PAL = {
      0: ['#030202', '#080605', '#100B08', '#1A120C'], 1: ['#140E0A', '#24180F', '#3B2919', '#5C4027'], 2: ['#0B0705', '#160E09', '#26190F', '#3D2A19'],
      3: ['#1A4F46', '#2A8576', '#5ED9BE', '#BFFCEB'], 4: ['#2A8576', '#5ED9BE', '#BFFCEB', '#FFFFFF'], 6: ['#1C1109', '#3A230F', '#5E3A18', '#8A5626'], 7: ['#0E1418', '#121A20', '#16212A', '#1A2732']
    };
    const RGB = {}; Object.keys(PAL).forEach((k) => { RGB[k] = PAL[k].map((h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]); });
    const bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    const torches = [{ x: cx - 21, y: gy - 16 }, { x: cx + 21, y: gy - 16 }];
    let frame = 0, raf = 0, last = 0, running = true;
    const px = (x, y, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); };
    const draw = () => {
      if (shown < target && frame % 2 === 0) shown++;
      cells.forEach((c, k) => { mat[c.i] = k < shown ? (c.hi ? 4 : 3) : c.base; });
      const lights = torches.map((t, k) => ({ x: t.x, y: t.y, r: 34, i: 0.95 + Math.sin(frame * 0.33 + k * 2) * 0.07 }));
      if (shown > 0) lights.push({ x: cx, y: gy, r: 10 + shown * 0.4, i: 0.6 });
      lights.forEach((l) => { l.r2 = l.r * l.r; });
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, m = mat[i];
        let L = m === 7 ? 0.5 : 0.04;
        if (m !== 7) for (let k = 0; k < lights.length; k++) { const l = lights[k], dx = x - l.x, dy = (y - l.y) * 1.1, d2 = dx * dx + dy * dy; if (d2 < l.r2) L += (1 - Math.sqrt(d2) / l.r) * l.i; }
        let lv = Math.floor(L * 3.1 + bayer[(x & 3) + ((y & 3) << 2)] / 16 - 0.3); lv = lv < 0 ? 0 : lv > 3 ? 3 : lv;
        if (m === 7) lv = y < 10 ? 0 : y < 20 ? 1 : 2;
        if (m === 3 || m === 4) lv = Math.max(lv, 2);
        const c = RGB[m][lv], o = i * 4; buf[o] = c[0]; buf[o + 1] = c[1]; buf[o + 2] = c[2]; buf[o + 3] = 255;
      }
      ctx.putImageData(img, 0, 0);
      stars.forEach((s, k) => { if ((frame + k * 7) % 90 > 4) px(s[0], s[1], k % 3 ? '#5C6A73' : '#9AA7AE'); });
      torches.forEach((t, k) => { const f = (frame + k * 3) % 6 < 3; px(t.x, t.y + 1, '#5E3A18'); px(t.x, t.y + 2, '#5E3A18'); px(t.x, t.y + 3, '#5E3A18'); px(t.x, t.y, '#F0A04B'); px(t.x, t.y - 1, f ? '#FFE3A0' : '#F0A04B'); if (f) px(t.x + 1, t.y - 2, '#FFE3A0'); else px(t.x - 1, t.y - 1, '#F0A04B'); });
    };
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const loop = (ts) => { if (!running) return; raf = requestAnimationFrame(loop); if (ts - last < 50) return; last = ts; frame++; draw(); };
    if (reduced) draw(); else raf = requestAnimationFrame(loop);
    return {
      open: () => { target = Math.round(cells.length * 0.35); if (reduced) { shown = target; draw(); } },
      close: () => { target = 0; shown = 0; if (reduced) draw(); },
      stop: () => { running = false; cancelAnimationFrame(raf); }
    };
  }

window.MineIt = { startCave, startTrack, startShaft, startMouth };
})();
