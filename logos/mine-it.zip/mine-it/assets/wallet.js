/* mine-it — Solana wallet connect (Wallet Standard + legacy Phantom fallback) */
(function () {
  'use strict';
  const STORE = 'mineit.wallet';
  const wallets = [];
  const state = { status: 'idle', addr: '', name: '', menu: false, err: '', copied: false };
  let active = null, offChange = null;
  const listeners = [];

  const el = (tag, attrs, kids) => {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      if (k === 'class') n.className = attrs[k];
      else if (k === 'text') n.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach((c) => c && n.appendChild(c));
    return n;
  };
  const store = { get() { try { return localStorage.getItem(STORE) || ''; } catch (e) { return ''; } }, set(v) { try { v ? localStorage.setItem(STORE, v) : localStorage.removeItem(STORE); } catch (e) {} } };

  // ---- discovery (Wallet Standard) ----
  const api = {
    register(...ws) {
      ws.forEach((w) => {
        const sol = w && Array.isArray(w.chains) && w.chains.some((c) => String(c).indexOf('solana:') === 0);
        if (sol && w.features && w.features['standard:connect'] && wallets.indexOf(w) < 0) wallets.push(w);
      });
      render(); tryAutoConnect();
      return () => { ws.forEach((w) => { const i = wallets.indexOf(w); if (i >= 0) wallets.splice(i, 1); }); render(); };
    }
  };
  window.addEventListener('wallet-standard:register-wallet', (e) => { try { if (e && typeof e.detail === 'function') e.detail(api); } catch (err) {} });
  try { window.dispatchEvent(new CustomEvent('wallet-standard:app-ready', { detail: api })); } catch (e) {}

  function options() {
    const opts = wallets.map((w) => ({ name: w.name, icon: w.icon || '', std: true, ref: w }));
    let legacy = null;
    try { legacy = (window.phantom && window.phantom.solana) || (window.solana && window.solana.isPhantom ? window.solana : null); } catch (e) {}
    if (legacy && !opts.some((o) => /phantom/i.test(o.name))) opts.push({ name: 'Phantom', icon: '', std: false, ref: legacy });
    return opts;
  }

  function set(patch) { Object.assign(state, patch); render(); listeners.forEach((f) => { try { f(getPublic()); } catch (e) {} }); }
  function getPublic() { return { connected: state.status === 'connected', address: state.addr, wallet: state.name }; }

  async function connect(o, silent) {
    if (!silent) set({ status: 'connecting', menu: false, err: '' });
    try {
      let addr = '';
      if (o.std) {
        const res = await o.ref.features['standard:connect'].connect(silent ? { silent: true } : undefined);
        const acc = (res && res.accounts && res.accounts[0]) || (o.ref.accounts && o.ref.accounts[0]);
        addr = acc ? acc.address : '';
        const ev = o.ref.features['standard:events'];
        if (ev && ev.on) offChange = ev.on('change', (p) => {
          if (!p || !p.accounts) return;
          const a = p.accounts[0];
          if (a) set({ addr: a.address }); else disconnect();
        });
      } else {
        const res = await o.ref.connect(silent ? { onlyIfTrusted: true } : undefined);
        addr = res && res.publicKey ? res.publicKey.toString() : '';
      }
      if (!addr) throw new Error('No account returned');
      active = o; store.set(o.name);
      set({ status: 'connected', addr, name: o.name, err: '' });
    } catch (e) {
      if (silent) { if (state.status !== 'connected') set({ status: 'idle' }); return; }
      const rejected = e && (e.code === 4001 || /reject|cancel|denied/i.test(String(e.message || '')));
      set({ status: 'idle', menu: true, err: rejected ? 'Request cancelled in your wallet.' : 'Couldn’t connect. Unlock your wallet and try again.' });
    }
  }

  async function disconnect() {
    const w = active;
    try {
      if (w && w.std && w.ref.features['standard:disconnect']) await w.ref.features['standard:disconnect'].disconnect();
      else if (w && !w.std && w.ref.disconnect) await w.ref.disconnect();
    } catch (e) {}
    if (offChange) { try { offChange(); } catch (e) {} offChange = null; }
    active = null; store.set('');
    set({ status: 'idle', addr: '', name: '', menu: false, err: '' });
  }

  let autoTried = false;
  function tryAutoConnect() {
    if (autoTried || state.status !== 'idle') return;
    const last = store.get(); if (!last) return;
    const o = options().find((x) => x.name === last); if (!o) return;
    autoTried = true; connect(o, true);
  }

  // ---- UI ----
  const mounts = [];
  function click(e) {
    e.stopPropagation();
    if (state.status === 'connecting') return;
    if (state.status === 'connected') { set({ menu: !state.menu, err: '' }); return; }
    const opts = options();
    if (opts.length === 1 && !state.err) { connect(opts[0]); return; }
    set({ menu: !state.menu, err: '' });
  }
  async function copy() {
    try { await navigator.clipboard.writeText(state.addr); set({ copied: true }); setTimeout(() => set({ copied: false }), 1400); }
    catch (e) { set({ err: 'Copy is blocked here. Select the address above instead.' }); }
  }

  const ICON = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#6FE3C8" stroke-width="1.6" aria-hidden="true"><path d="M2 4.5h10.5v9H2z"/><path d="M2 4.5 10 2v2.5"/><path d="M10 8.5h4v2.5h-4z"/></svg>';

  function render() {
    const connected = state.status === 'connected';
    const short = state.addr ? state.addr.slice(0, 4) + '…' + state.addr.slice(-4) : '';
    mounts.forEach((m) => {
      m.btn.innerHTML = '';
      if (connected) m.btn.appendChild(el('span', { class: 'wallet-dot' }));
      else { const s = el('span'); s.innerHTML = ICON; s.style.display = 'inline-flex'; m.btn.appendChild(s); }
      m.btn.appendChild(el('span', { class: 'num', text: state.status === 'connecting' ? 'Connecting…' : connected ? short : 'Connect your wallet' }));
      m.btn.setAttribute('aria-expanded', state.menu ? 'true' : 'false');

      const menu = m.menu; menu.innerHTML = ''; menu.hidden = !state.menu;
      if (!state.menu) return;
      if (state.err) menu.appendChild(el('div', { class: 'wallet-err', text: state.err }));
      if (connected) {
        menu.appendChild(el('div', { class: 'wallet-head' }, [el('span', { class: 'eyebrow muted', text: state.name }), el('span', { class: 'wallet-addr', text: state.addr })]));
        menu.appendChild(el('button', { type: 'button', role: 'menuitem', class: 'menu-item', text: state.copied ? 'Copied' : 'Copy address', onclick: copy }));
        menu.appendChild(el('a', { href: '/mine', role: 'menuitem', class: 'menu-item', text: 'My ore' }));
        menu.appendChild(el('button', { type: 'button', role: 'menuitem', class: 'menu-item warn', text: 'Disconnect', onclick: disconnect }));
        return;
      }
      const opts = options();
      if (!opts.length) {
        menu.appendChild(el('div', { class: 'menu-note', text: 'No Solana wallet found in this browser.' }));
        menu.appendChild(el('a', { href: 'https://phantom.com/download', target: '_blank', rel: 'noopener', class: 'menu-item mono', text: 'Get Phantom →' }));
        return;
      }
      menu.appendChild(el('div', { class: 'eyebrow muted', text: 'Choose a wallet', style: 'padding:4px 8px 6px' }));
      opts.forEach((o) => {
        const icon = o.icon ? el('img', { src: o.icon, alt: '', width: '24', height: '24' }) : el('span', { class: 'wi', text: o.name.charAt(0) });
        menu.appendChild(el('button', { type: 'button', role: 'menuitem', class: 'menu-item', onclick: () => connect(o) }, [icon, el('span', { text: o.name })]));
      });
    });
  }

  function mount(host) {
    const btn = el('button', { type: 'button', class: 'btn btn-dark btn-sm px', 'aria-haspopup': 'menu', 'aria-expanded': 'false', onclick: click });
    const menu = el('div', { role: 'menu', class: 'wallet-menu px' }); menu.hidden = true;
    host.classList.add('wallet'); host.appendChild(btn); host.appendChild(menu);
    mounts.push({ host, btn, menu });
  }

  document.addEventListener('pointerdown', (e) => { if (state.menu && !mounts.some((m) => m.host.contains(e.target))) set({ menu: false }); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && state.menu) set({ menu: false }); });

  function init() {
    document.querySelectorAll('[data-wallet]').forEach(mount);
    render();
    setTimeout(tryAutoConnect, 400); // legacy providers inject without registering
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  window.mineitWallet = { onChange(f) { listeners.push(f); f(getPublic()); }, get: getPublic };
})();
