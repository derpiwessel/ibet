/* mine-it — mine page (simulated data until the backend is live) */
(function () {
  'use strict';
  const RATE = 38; // $PICK per second at this sample share
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, text, style) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; if (style) n.setAttribute('style', style); return n; };
  const full = (n) => Math.floor(n).toLocaleString('en-US');
  const short = (n) => n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'K' : String(Math.round(n));
  const ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 2 ? 'now' : s < 60 ? s + 's ago' : Math.floor(s / 60) + 'm ago'; };
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const st = { pending: 28140, claimed: 412600, claiming: false, vein: 18420000 };
  let feed = [[1.92, 260000, 7], [0.64, 87000, 31], [2.75, 371000, 58], [1.08, 146000, 95]].map((r) => ({ sol: r[0].toFixed(2), tokens: r[1], t: Date.now() - r[2] * 1000, fresh: false }));

  const shaft = window.MineIt.startShaft($('#shaft'));

  // static pieces
  const share = $('#share-bar');
  for (let k = 0; k < 24; k++) share.appendChild(el('span', null, null, 'width:6px;height:10px;background:' + (k < 2 ? '#6FE3C8' : '#241A14')));
  const veinBar = $('#vein-bar');
  const veinCells = []; for (let k = 0; k < 40; k++) { const s = el('span', null, null, 'flex:1 1 0;height:14px'); veinCells.push(s); veinBar.appendChild(s); }
  $('#rate').textContent = full(RATE * 60);

  function renderNumbers() {
    $('#pending').textContent = full(st.pending);
    $('#claimed').textContent = full(st.claimed) + ' $PICK';
    const b = $('#claim');
    b.disabled = st.claiming || st.pending < 1;
    b.textContent = st.claiming ? 'Hauling it up…' : 'Claim ' + short(st.pending) + ' $PICK';
    $('#vein-left').textContent = short(st.vein) + ' $PICK';
    const on = Math.max(1, Math.min(40, Math.round((st.vein / 25e6) * 40)));
    veinCells.forEach((c, k) => { c.style.background = k < on ? (k % 7 === 3 ? '#BFFCEB' : '#5ED9BE') : '#241A14'; });
  }
  function renderFeed() {
    const box = $('#feed'); box.textContent = '';
    feed.forEach((f) => {
      const row = el('div', 'feed-row' + (f.fresh ? ' feed-item' : ''));
      const l = el('span');
      l.append(el('span', null, f.sol + ' SOL', 'color:#F0A04B'), ' → ', el('span', null, short(f.tokens) + ' buried', 'color:#6FE3C8'));
      row.append(l, el('span', 'muted', ago(f.t)));
      box.appendChild(row); f.fresh = false;
    });
  }

  $('#claim').addEventListener('click', () => {
    if (st.claiming || st.pending < 1) return;
    st.claiming = true; renderNumbers();
    shaft.haul(() => {
      st.claimed += Math.floor(st.pending); st.pending = 0; st.claiming = false; renderNumbers();
      const p = $('#pending'); p.classList.remove('pop'); void p.offsetWidth; p.classList.add('pop');
    });
  });

  setInterval(() => { if (!st.claiming) st.pending += RATE / 4; st.vein = Math.max(0, st.vein - 120); renderNumbers(); }, reduced ? 1000 : 250);
  setInterval(renderFeed, 1000);
  setInterval(() => {
    const sol = 0.3 + Math.random() * 2.8, tokens = Math.round(sol * 135000);
    feed = [{ sol: sol.toFixed(2), tokens, t: Date.now(), fresh: true }].concat(feed).slice(0, 4);
    st.vein += tokens; renderFeed(); renderNumbers(); shaft.buyback();
  }, 6500);

  if (window.mineitWallet) window.mineitWallet.onChange((w) => {
    $('#wallet-note').textContent = w.connected ? 'Connected. Your real bag shows here once mines are live; these numbers are a sample.' : 'Sample bag. Connect your wallet to see your own.';
  });

  renderNumbers(); renderFeed();
})();
